from flask_wtf import FlaskForm
from wtforms import Form, TextAreaField, validators, StringField, SubmitField, IntegerField, RadioField, FloatField
from wtforms.validators import DataRequired, Length

class UserInfoForm(FlaskForm):

    name = StringField('Name:', 
    					validators=[DataRequired(), Length(min=2,max=20)])
    weight = IntegerField('Weight:', validators=[DataRequired(message="No valid value")])
    height = FloatField('Height:', validators=[DataRequired(message="No valid value")] )
    age = IntegerField('Age:', validators=[DataRequired(message="No valid value")])
    gender = RadioField('Gender',choices=[('Male','Male'),('Female','Female')],default='Male',validators=[DataRequired()])
    physical_activity=RadioField('Choose your weight loss plan :',
	    						choices=[
	    									('value1','Maintain Weight'),
	    									('value2','Mild Weight Loss'),
	    									('value3','Weight Loss'),
	    									('value4','Extreme Weight Loss'),
	    									('value5','Weight Gain')

	    								],
	    						default='value1',
	    						validators=[DataRequired()])
    submit = SubmitField('Submit')